hljs.initHighlightingOnLoad();
layui.use(['layer', 'form', 'element'], function () {
    var $ = layui.jquery;
    var layer = layui.layer;
    var form = layui.form;
    var element = layui.element;
    var editor = ace.edit('editor');
    editor.setFontSize(14);
    editor.getSession().setMode("ace/mode/c_cpp");
    editor.setTheme("ace/theme/clouds");
    editor.getSession().setTabSize(4);
    editor.setShowPrintMargin(false);
    editor.setOptions({
        fontFamily: "tahoma",
        fontSize: "10pt"
    });


    var url = 'https://wandbox.org/api/compile.json'
    $('#btnRun').click(function () {
        var code = editor.getValue();
        console.log(code);
        return false;


        admin.req(url, {
            code: editor.getValue(),
            compiler: 'gcc-10.1.0',
            options: 'cpp-pedantic,c++2a',
            stdin: '',
        }, function (res) {
            console.log(res);
        }, 'post');
    });

    var html = `
输入两个整数，求这两个整数的和是多少。

**输入格式**

输入两个整数A,B，用空格隔开，0≤A,B≤108

**输出格式**

输出一个整数，表示这两个数的和

**样例输入：**

<code class="hljs">3 4</code>
**样例输出：**
<code class="hljs">7</code>
    `;
    var markdown = document.getElementById('zpTopic');
    markdown.innerHTML = marked(html, { breaks: false });
});